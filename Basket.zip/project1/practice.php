<!DOCTYPE html>
<html>
    <head>
        <title>Homepage</title>
        <link rel="stylesheet" href="practice.css">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="main" style=" width: 100%;
        background:linear-gradient(to top, rgba(0, 0, 0, 0.5)50%,rgba(0,0,0,0.5)50%), url(image.jpg);
        background-position: center;
        background-size: cover;
        height: 150vh;">
            <div class="navbar" style="width:1200px; height:75px; margin:auto;">
                <div class="icon" style="width:200px; height:70px; float:left;">
                    <h2 class="logo" style="color:#fff; font-size: 35px; font-family: Arial; padding-left: 3px; float:left; padding-top: 5px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</h2>
                    
                </div>
                <div class="menu" style="width: 400px; float: left; height: 70px;">
                    <ul style="float: left; display:flex; justify-content: center; align-items: center;">
                        <li><a href="#">HOME</a></li>
                        <li><a href="about.php">ABOUT</a></li>
                        <li><a href="support.php">SUPPORT</a></li>
                        <li><a href="contact.php">CONTACT</a></li>
                    </ul>
                </div>
            </div>
            <div class="content">
                <h1><i>Instant</i> <br>
                    delivery of all your <br>
                    <span style="color: #ff7200;font-size: 60px;">grocery</span> needs</h1>
                <p class="para">An online grocer is either a brick-and-mortar supermarket or grocery<br>
                    store that allows online ordering, or a standalone e-commerce service<br>
                    that includes grocery items.</p>
                <div class="form">
                    <h2>Login Here</h2>
                    <input type="email" name="email" placeholder="Enter the email">
                    <input type="password" name="password" placeholder="enter the password">
                    <button class="btn"><a href="">Login</a></button>

                    <p class="link">Don't have an account<br>
                    <a href="sign.php">Sign up </a>here</p>
                    <p class="liw">Login with</p>

                    <div class="icon">
                        <a href="https://www.facebook.com/"><ion-icon name="logo-facebook"></ion-icon></a>
                        <a href="https://www.instagram.com/"><ion-icon name="logo-instagram"></ion-icon></a>
                        <a href="https://twitter.com/i/flow/login"><ion-icon name="logo-twitter"></ion-icon></a>
                        <a href="https://accounts.google.com/ServiceLogin/webreauth?rart=ANgoxcdbbNxH1nYXChBQ7n_DhSet9sRm1XXzUFTdrodQQJThJv3oPCktvjFuZq-YDK8WsXHW_gXYeU7G-XB1iBPG0qMJAeBgcA&flowName=GlifWebSignIn&flowEntry=ServiceLogin"><ion-icon name="logo-google"></ion-icon></a>
                        <a href="https://www.skype.com/en/"><ion-icon name="logo-skype"></ion-icon></a>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
    </body>
</html>