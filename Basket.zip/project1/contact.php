<!DOCTYPE html>
<html><head>
    <title>ABOUT</title>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="main" style=" width: 100%;
        background-color:rgb(65, 71, 69);
        background-position: center;
        background-size: cover;
        height: 35vh;">
        <h1 class="logo" style="color:rgb(19, 241, 19); font-size: 60px; font-family:Arial Narrow Bold; font-weight: bold; padding-left: 36%; float:left; padding-top: 50px;">B a s k <i class="fa fa-shopping-cart" style="font-size:60px;color:#ff7200;"></i> t</h1>
        <p style="padding-left: 45%; float:left; padding-top: 1px; color:white;  font-size: 30px;">Contact Us</p>
        </div>
        <span style="padding-left:300px; padding-top:50px; padding-bottom:10px;"><img src="map.png" width="50%"></span>
        <div>.</div>
        <h2 align="center" style="padding-bottom:10px;"><u>BASKET GROCERY STORE LIMITED</u></h2>
        <p style="font-size:20px" align="center">'NARENDRA KUMAR' E2,<br>
            RGUKT RKV Idupulapaya Village,<br>Vempalli Mandalam,Kadapa Dist.<br> 516330,Andhra Pradesh,India.<br> Ph no: 6304484450</p>
            
           
            
            
        
        
        </body>
</html>