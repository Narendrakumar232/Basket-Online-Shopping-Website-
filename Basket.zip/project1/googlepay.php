<!DOCTYPE html>
<html>
    <head>
        <title>Proceed to pay</title>
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    
       <div style="border-radius:10px; background-color: #bad617;">
        <b><h1 class="logo" style="color:black; font-size: 40px; font-family:Helvetica; padding-left: 550px; float:left; padding-top: 50px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</b></h1>
        <strong><h3 style="padding-left:410px; padding-top:120px;padding-bottom: 30px;">Enter Digital Pay registered UPI ID</h3></strong></div>
        <p style="padding-left:350px;font-size:30px; padding-top:50px">UPI ID</p>
        <form action="paytosucess.php" id="form">
        <center><input type="text" placeholder="Enter UPI ID" size="60" id="name"><br><br>
            <input type="checkbox" name="checked" id="check">
            <label> I accept the <u>Terms and Conditions</u></label><br><br>
            <button class="btn btn-success" type="submit">VERIFY</button><br><br>
            <span id="error" style="color: #ff7200"></span></form>
            <h5>________________________________OR________________________________</h5></center>
            <p style="padding-left:350px;font-size:30px; padding-top:50px">SCAN TO PAY</p>
            <center><img src="qr.webp" width="400px" height="400px"></center>
            <div class="card">
            <div class="card-footer mb-5">
                <img src="visa2.jpeg" width="100px" style="margin-left:160px">
                <img src="master.png" width="100px" style="margin-left:130px">
                <img src="rupay.jpg" width="100px" style="margin-left:160px">
                <img src="bharat.png" width="100px" style="margin-left:190px"><br>
                
                <b><h1 class="logo" style="color:black; font-size: 40px; font-family:Helvetica; padding-left: 550px; float:left; padding-top: 50px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</b></h1>
                <p align="right" style="padding-top:60px; padding-right:-20px">Privacy Policy</p>
            </div>
        </div>
        
<script>
    let form=document.getElementById('form');
    let uname=document.getElementById('name');
    let ucheck=document.getElementById('check');

    let uerror=document.getElementById('error');
    form.addEventListener("submit",event=>{event.preventDefault();validate();})
        function validate(){
            let name=uname.value.trim();

            if(name===""||name==null){
                uerror.innerText="# cant be empty";
            }
            else if(name.length<3){
                uerror.innerText="# must be conatin 3 letters";
                }
            else if(!(name.match(/^[a-zA-Z0-9_/.-]+@[a-z]+$/))){
                uerror.innerText="# invalid UPI";
            }
            else if(ucheck.checked === false){
                uerror2.innerText="# Please accept the terms and conditions";
            }
            else{
                form.submit();
            }
        }
</script>
<div class="ntg">
    <nav class="navbar navbar-expand-lg navbar-light fixed-bottom">
        <ul class="navbar-nav" style="background: radial-gradient(#fff,#ffd6d6);">
            <li class="nav-item">
                <a href="payments.php" class="nav-link active"><i class="fa fa-home" style="font-size:28px; padding-left: 250px; padding-right: 350px"></i></a>

            </li>
            
            <li class="nav-item">
                <a href="store.php" class="nav-link"><i class='fa fa-shopping-bag' style='font-size:28px;padding-right: 350px;'></i></a>
            </li>
            <li class="nav-item">
                <a href="mycart2.php" class="nav-link"><i class="fa fa-shopping-cart" style="font-size:28px;padding-right: 350px;"></i></a>
            </li>
            </ul>
            
        </nav>
        </div>  
    
    </body>
</html>