<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>user details</title>
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
        <meta name="viewpoint" content="width=device-width,initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <div class="main" style=" width: 100%;
        background-color: rgb(53, 242, 198);
        background-position: center;
        background-size: cover;
        height: 30vh;">
         <h1 class="logo" style="color:black; font-size: 40px; font-family: Arial; padding-left: 550px; float:left; padding-top: 20px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</h1>
        <span style="padding-left:550px;"><img class="mt-5" src="image2.webp" style="border-radius: 50%" width="200px" height="200px"></span><br>
       
        <p style="font-size:30px; padding-left:540px;margin-top:30px; color:orange;font-weight:bold;"> <?php
        echo $_SESSION['uname']."<br>";
        ?><i></i><p>
        <p style="font-size:30px; padding-left:530px;margin-top:-5px"> <?php
        echo $_SESSION['email']."<br>";
        ?><i></i><p>
        <p style="font-size:30px; padding-left:510px;margin-top:-5px">Password: ************
        <i></i><p>

        <div class="ntg">
    <nav class="navbar navbar-expand-lg navbar-light fixed-bottom">
    <ul class="navbar-nav" style="background: radial-gradient(#fff,#ffd6d6);">
     <li class="nav-item">
     <a href="2.php" class="nav-link active"><i class="fa fa-home" style="font-size:28px; padding-left: 250px; padding-right: 350px"></i></a>
                                                                                                                        
     </li>
                                                                                                                                    
    <li class="nav-item">
    <a href="store.php" class="nav-link active"><i class='fa fa-shopping-bag' style='font-size:28px;padding-right: 350px;'></i></a>
    </li>  
    <li class="nav-item">
    <a href="mycart2.php" class="nav-link active"><i class="fa fa-shopping-cart" style="font-size:28px;padding-right: 350px;"></i></a>
                </li>
            </nav>
    </div>         


        

    </body>
</html>