<!DOCTYPE html>
<html>
    <head>
        <meta lan="en">
        <meta charset="utf-8">
        <meta name="viewpoint" content="width=device-width,initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <title>Support</title>
    </head>
    <body>
        <h2 align="center" style="border-radius:10px; background-color:aqua; padding-top:10px">BASKET SUPPORT</h2>
        <div style="color:black; padding-left:20px; padding-bottom: 20px; padding-top: 60px;"><h2>Issues related to an order</h2>
        </div>
        <div class="container">
            <div class="accordion" id="accordionex">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingtwo">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapsetwo" aria-expanded="true" aria-control="collapsetwo">
                        <strong>I have a payment or refund related query</strong>
                        </button>
                    </h2> 
                    <div id="collapsetwo" class="accordion-collapse collapse show" aria-labelledby="headingtwo" data-bs-parent="accordionex">
                        <div class="accordion-body">
                            <p>please let us know how we may help</p><br>
                            <button type="button" onclick="fun();">chat</button>
                            <span id="error"></span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="container">
            <div class="accordion" id="accordionex1">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingone">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseone" aria-expanded="true" aria-control="collapseone">
                            <strong>I have a promotion code or BASKET cash related query</strong>
                        </button>
                    </h2> 
                    <div id="collapseone" class="accordion-collapse collapse show" aria-labelledby="headingone" data-bs-parent="accordionex1">
                        <div class="accordion-body">
                            <p>please let us how we may help</p><br>
                            <button type="button" onclick="fun();">chat</button>
                            <span id="error"></span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </body>
</html>