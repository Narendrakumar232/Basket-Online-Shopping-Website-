<?php
    session_start();
    ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Homepage</title>
        <link rel="stylesheet" href="practice.css">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="main" style=" width: 100%;
        background:linear-gradient(to top, rgba(0, 0, 0, 0.5)50%,rgba(0,0,0,0.5)50%), url(back3.jpg);
        background-position: center;
        background-size: cover;
        height: 150vh;">
            <div class="navbar" style="width:1200px; height:75px; margin:auto;">
                <div class="icon" style="width:200px; height:70px; float:left;">
                    <h2 class="logo" style="color:#fff; font-size: 35px; font-family: Arial; padding-left: 3px; float:left; padding-top: 5px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</h2>
                    
                </div>
                <div class="menu" style="width: 400px; float: left; height: 70px;">
                    <ul style="float: left; display:flex; justify-content: center; align-items: center;">
                        <li><a href="practice.php">HOME</a></li>
                        <li><a href="about.php">ABOUT</a></li>
                        <li><a href="support.php">SUPPORT</a></li>
                        <li><a href="contact.php">CONTACT</a></li>
                    </ul>
                </div>
            </div>
            <div class="content">
                <h1><i>Start</i> <br>
                    your week with a <br>
                    <span style="color: #ff7200;font-size: 60px;">Smile</span> &#128512</h1>
                <p class="para">Fill your cart with our fresh produce,home items and fruits <b style="color: orange;">from our shelves.</b></p>
                <div class="form">
                    <h2>Sign Here</h2>
                    <form id="form" action="2.php" method="post">
                    <input type="text" name="uname" placeholder="Enter the name" id="uname">
                    <input type="email" name="email" placeholder="Enter the email" id="uemail">
                    <input type="password" name="password" placeholder="enter the password" id="pass">
                    <input type="password" name="password" placeholder="enter the re-password" id="con">
                    <button class="btn" type="submit" style="background-color:red;">Create account</button>
                </form>
                </div>
                </div>
           
        
        <span id="error" style="padding-left:300px; color:red; font-size:30px"></span>
    </div> </div>
        <script>
            let form=document.getElementById('form');

            let uname=document.getElementById('uname');
            let uemail=document.getElementById('uemail');
            let upass=document.getElementById('pass');
            let ucon=document.getElementById('con');function naren(){
            if(upass.type=="password"){
                upass.type="text";
            }
            else{
                upass.type="password";
            }
        }  

            let error=document.getElementById('error');

            form.addEventListener("submit",event=>{event.preventDefault();validate();})
        function validate(){
            let name=uname.value.trim();
            let psd=upass.value.trim();
            let cpsd=ucon.value.trim();
            let em=uemail.value.trim();
            if(name===""||name==null){
                error.innerText="#Name cant be empty";
            }
             else if(name.length<3){
                error.innerText="#Name must be conatin 3 letters";
                }
           else if(!isNaN(name)){
                error.innerText="#Name only alphabets";
            }
            else if(psd===""||psd==null){
                error.innerText="#password cant be empty";
            }
            else if(!(psd.match(/[a-z]+[A-Z]+[0-9]+/) || (/[A-Z]+[a-z]+[0-9]/))){
                error.innerText="#Password must used aleast one capital,small,digit";
            }
            else if(!psd.match(/[#_@$^%]/)){
                error.innerText="#Password contain atleast one special character";
            }
            else if(psd!=cpsd){
                error.innerText="#confirm password Not match";
            }
            else if(em===""||em==null){
                error.innerText="#Email cant be empty";
            }
            else if(!(em.match(/^[a-zA-Z0-9_/.-]+@[a-zA-Z0-9_-]+(?:\.[a-z]{2,6})$/))){
                error.innerText="#Invalid mail";
            }
            else{
       	        form.submit();
       	    }
        } 
        function naren(){
            if(upass.type=="password"){
                upass.type="text";
            }
            else{
                upass.type="password";
            }
        }  
        </script>

        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
    </body>
</html>