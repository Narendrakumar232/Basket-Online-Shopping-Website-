<html>
    <head><title>address</title>
    <link rel="stylesheet" src="bootstrap.css">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <div style="border-radius:10px; background: linear-gradient(-70deg, #fa7c30 30%, rgba(0, 0, 0, 0) 30%), url('3d-hd-wallpaper-for-laptop.jpeg');">
        <b><h1 class="logo" style="color:black; font-size: 40px; font-family:Helvetica; padding-left: 550px; float:left; padding-top: 50px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</b></h1>
        <strong><h3 style="padding-left:546px; padding-top:120px;padding-bottom: 30px;">YOUR ADDRESS</h3></strong>
    </div><br>
        <a href="mycart2.php"><button class="btn btn-dark ms-4">>prev</button></a><br>
    <center><select style="width:500px;text-align:center;background-color:#39CCCC; border 2px solid">
        <option selected style="background-color:white">INDIA</option>
        <option style="background-color:white">USA</option>
        <option style="background-color:white">PAKISTAN</option>
        <option style="background-color:white">SRILANKA</option>
        <option style="background-color:white">BANGLADESH</option>
        <option style="background-color:white">NEPAL</option>
        <option style="background-color:white">ENGLAND</option>
        </select></center><br>
        <center><form method="POST" action="payments.php">
            <label class="form-label"><h3>Full name:</h3></label><br>
            <input type="text" name="uname" size="30" placeholder="Your Name" required style="border: 3px solid black"><br><br>
           <label class="form-label"><h3>Mobile:</h3></label><br>
            <input type="tel" name="uname" size="30" placeholder="Phone Number" required style="border: 3px solid black"><br><br>
            <label class="form-label"><h3>Pincode:</h3></label><br>
            <input type="tel" name="uname" size="30" placeholder="Pincode"  required style="border: 3px solid black"><br><br>
            <label class="form-label"><h3>House No:</h3></label><br>
            <input type="text" name="uname" size="30" placeholder="House NO" required style="border: 3px solid black"><br><br>
            <label class="form-label"><h3>Village:</h3></label><br>
            <input type="text" name="uname" size="30" placeholder="Village Name" required style="border: 3px solid black"><br><br>
            <label class="form-label"><h3>Town/City:</h3></label><br>
            <input type="text" name="uname" size="30" placeholder="Town/city Name"  required style="border: 3px solid black"><br><br>
            <label class="form-label"><h3>State:</h3></label><br>
            <input type="text" name="uname" size="30" placeholder="State" required style="border: 3px solid black"><br><br><br>
            <input type="submit" value="PROCEED TO PAY" style="background-color:yellow"><br><br>


        </form></center>
        <h3 style="padding-left:40px;"> Add delivery instructions :</h3>
        <p style="padding-left:40px;font-size:20px; padding-top:10px; font-weight:medium; color:#ff7200;"> Preference are used to plan your delivery.
        However,shipments can sometimes arrive early or later than planned.</p>
</body>
</html>