<!DOCTYPE html>
<html>
    <head>
        <title>payments</title>
        <link rel="stylesheet" src="bootstrap.css">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <style>
            a {
              text-decoration: none;
              display: inline-block;
              padding: 8px 16px;
              margin-left: 10px;
              margin-top: 20px
            }
            
            .previous {
              background-color: #f1f1f1;
              color: black;
            }
            
            .round {
              border-radius: 50%;
            }
            </style>
            </head>
            <body>
                <div class="main" style=" width: 100%;
                background-color: #a3b1ba;
                background-position: center;
                background-size: cover;
                height: 30vh;">    
            <a href="address.php" class="previous round">&#8249;</a>
            <h2 style="font-size:40px;font-weight: bold; padding-top: -80px;" align="center"> Select payment method</h2></div>
                    <div class="main" style=" width: 1200px;
                    font-family: sans-serif;
                    text-align: center;
                    background-color: rgb(202, 230, 252);
                    border-radius: 10px;
                    margin-left: 80px;
                    margin-right: 80px;
                    margin-top: 80px;
                    padding-top: 10px;
                    padding-bottom:5px;" align="center"><h4 style="font-weight:bold;">Get 10% cashback upto <i class="fa fa-rupee"></i>50</h4>
                    <p>pay with Basket Pay UPI,T&C apply<p style="color:blue">Link your bank account now</p></p>
                </div>
              <center><a href="googlepay.php"><button style="background-color:yellow">Continue</button></a></center>
               <h3 style="padding-left:20px">More ways to pay</h3>
               <div class="container">
                <div class="accordion" id="accordionex1">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingtwo1">
                            <div class="main" data-bs-toggle="collapse" data-bs-target="#collapsetwo1" aria-expanded="true" aria-control="collapsetwo1" style=" width: 1200px;
                    font-family: sans-serif;
                    text-align: center;
                    font-size: 30px;
                    background-color: rgb(202, 230, 252);
                    border-radius: 20px;
                    margin-left: -40px;
                    margin-right: 80px;
                    margin-top: 40px;
                    padding-left: -830px;" align="center"><i class="fa fa-check-square-o" aria-hidden="true"></i>Other <span style="color:rgb(255, 149, 11);">UPI IDs/Net Banking <i class="fa fa-angle-down" style='font-size:36px; padding-left:100px'></i></span>
                </div></h2>
                <div id="collapsetwo1" class="accordion-collapse collapse show" aria-labelledby="headingtwo1" data-bs-parent="accordionex1">
                    <div class="accordion-body">
                        <form style="font-size: 30px;" action="googlepay.php" id="form1">
                            <input type="radio" name="pay" style="width: 25px; height: 25px;">
                            <label style="padding-left:20px;">Google Pay</label>
                            <span><img src="google.svg" width="40px" height="40px" align="right"></span><br>
                            <input type="radio" name="pay" style="width: 25px; height: 25px;">
                            <label style="padding-left:20px;">Phone Pay</label>
                            <span><img src="phone.png" width="40px" height="40px" align="right"></span><br>
                            <input type="radio" name="pay" style="width: 25px; height: 25px;">
                            <label style="padding-left:20px;">Paytm</label>
                            <span><img src="pay.png" width="40px" height="40px" align="right"></span><br>
                            <input type="radio" name="pay" style="width: 25px; height: 25px;">
                            <label style="padding-left:20px;">Net Banking</label>
                            <span><img src="net.webp" width="40px" height="40px" align="right"></span><br>
                            <center><button  class="btn btn-danger" style="background-color: rgb(209, 79, 79); border-radius: 10px; color:white">Continue</button></center>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="container">
        <div class="accordion" id="accordionex2">
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingtwo2">
                <div class="main"  data-bs-toggle="collapse" data-bs-target="#collapsetwo2" aria-expanded="true" aria-control="collapsetwo2" style=" width: 1200px;
                    font-family: sans-serif;
                    text-align: center;
                    font-size: 30px;
                    background-color: rgb(202, 230, 252);
                    border-radius: 20px;
                    margin-left: -40px;
                    margin-right: 80px;
                    margin-top: 40px;
                    padding-left: 20px;" align="center"><i class="fa fa-check-square-o" aria-hidden="true"></i> ADD <span style="color:rgb(255, 149, 11)">Debit/Credit/ATM Card <i class="fa fa-angle-down" style="font-size:36px; padding-left:100px; color:rgb(255, 149, 11)"></i></span>
                </div>
                </h2>
                <div id="collapsetwo2" class="accordion-collapse collapse show" aria-labelledby="headingtwo2" data-bs-parent="accordionex2">
                    <div class="accordion-body">
                        <center><form style="text-align:center" action="paytosucess.html" id="form2">
                            <label style="font-size:30px; font-weight:bold; padding-bottom: 10px;">Card Number:</label>
                            <span><img src="atm.jpg" width="40px" height="40px" align="right"></span><br>
                            <input type="text" placeholder="*************" size="50" id="name"><br><br>
        
                        <label style="font-size:30px; font-weight:bold; padding-bottom: 10px;">Valid thru:</label><br>
                        <input type="number" placeholder="MM" size="2" id="check">
                        <input type="number" placeholder="YY" size="2" id="check2">
                        <input type="number" placeholder="CVV" size="10" id="check3"><br> <br>
                        <center><a href="googlepay.php"><button  type="submit" class="btn btn-danger" style="background-color: rgb(209, 79, 79); border-radius: 10px; color:white">Continue</button></a>
                        <span id="error" style="color:red"></span></center>
                    </form></center>
                    </div>
                </div>
            </div>
        </div>

    </div>
                <div class="container">
                    <div class="accordion" id="accordionex">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingtwo">
                <div class="main" data-bs-toggle="collapse" data-bs-target="#collapsetwo" aria-expanded="true" aria-control="collapsetwo" style=" width: 1200px;
                    font-family: sans-serif;
                    text-align: center;
                    font-size: 30px;
                    background-color: rgb(202, 230, 252);
                    border-radius: 20px;
                    margin-left: -40px;
                    margin-right: 80px;
                    margin-top: 40px;
                    padding-left: -330px;" align="center"><i class="fa fa-check-square-o" aria-hidden="true"></i>  Pay on <span  style="color:rgb(255, 149, 11)">Delivery</span><p>Pay using cash,paylink (debit,credit card,UPI) or Scan <i class="fa fa-angle-down" style='font-size:36px; padding-left:100px; color:rgb(255, 149, 11)'></i></p>
                </div></h2>
                <div id="collapsetwo" class="accordion-collapse collapse show" aria-labelledby="headingtwo" data-bs-parent="accordionex">
                    <div class="accordion-body">
                        <center><a href="paytosucess.php"><button  class="btn btn-danger" style="background-color: rgb(209, 79, 79); border-radius: 10px; color:white">Continue</button></a></center>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-1">.</div>
    </div>
    <div class="row">
        <div class="col-md-1"></div>
    </div>
    <div class="row">
        <div class="col-md-1">.</div>
    </div>
    <div class="row">
        <div class="col-md-1">.</div>
    </div>



        <script>
            let form=document.getElementById('form2');
            let uname=document.getElementById('name');
            let ucheck=document.getElementById('check');
            let ucheck2=document.getElementById('check2');
            let ucheck3=document.getElementById('check3');
        
            let uerror=document.getElementById('error');
            form.addEventListener("submit",event=>{event.preventDefault();validate();})
                function validate(){
                    let name=uname.value.trim();
        
                    if(name===""||name==null){
                        uerror.innerText="# cant be empty";
                    }
                    else if(name.length!=12){
                        uerror.innerHTML="# invalid Card Number"
                    }
                    else if(!(name.match(/[\d]{10}/))){
                        uerror.innerText="# invalid Card Number";
                    }
                    else if(ucheck===""||ucheck==null){
                        uerror.innerText="# cant be empty";
                    }
                    
                    
                    else if(ucheck2===""||ucheck2==null){
                        uerror.innerText="# cant be empty";
                    }
                    
                    else if(ucheck3===""||ucheck3==null){
                        uerror.innerText="# cant be empty";
                    }
                  
                    else{
                        form.submit();
                    }
                }
        </script>    
    </body>
</html>