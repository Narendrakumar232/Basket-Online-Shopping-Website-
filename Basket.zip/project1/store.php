<!DOCTYPE html>
<html>
    <head>
        <title>Stores</title>
    </head>
    <body>
        <!DOCTYPE html>
<html>
    <head>
        <title>Inpage</title>
        <link rel="stylesheet" href="2.css">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="main" style=" width: 100%;
        background-color: green;
        background-position: center;
        background-size: cover;
        height: 30vh;">
         <div class="navbar" style="width:1200px; height:75px; margin:auto;">
            <div class="icon" style="width:200px; height:70px; float:left;">
                <h1 class="logo" style="color:#fff; font-size: 40px; font-family: Arial; padding-left: 3px; float:left; padding-top: 15px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</h1> <a href="user.php"><i class="fa fa-user" style="font-size:38px; color:#fff; padding-left: 1200px; padding-top: 5px; margin-top: -55px;"></i></a>
                <p style="color:#fff; font-size: 13px; font-family: Arial; float: left;">Groceries delivered fresh and fast</p>
                <form style="margin-left: 400px;
                margin-top: 20px;
                font-size: 14px; padding: 12px; width: 340px;" >
                    <input type="search" placeholder="search..." class="st-default-search-input" style="width: 400px; height: 40px;">
                    <h1 style="margin-left:360px; margin-top:-48px"><i class="fa fa-search" style="font-size:26px"></i></h1>
                    <button class="btn btn-danger" style="margin-left:420px; margin-top:-78px">search</button>
                </form>
            </div>
        </div>
    </div>
    <h3 style="padding-top:20px; padding-left:20px; padding-bottom: 10px;">Essentials delivered to you doorstep</h3>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                <a href="https://www.google.com/search?q=rk%20valley%20%20grocery%20shopping&client=ubuntu&hl=en&biw=1366&bih=656&ei=LjIYY-1Tno6x4w-ioYOICQ&ved=2ahUKEwir9r_LgYL6AhWC_3MBHWchDs0QvS56BAgJEAE&uact=5&oq=rk+valley++grocery+shopping&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEKIEMgUIABCiBDIFCAAQogQ6CggAEEcQ1gQQsAM6DQgAEEcQ1gQQsAMQyQM6CAgAEJIDELADOgcIABCxAxBDOgYIABAeEAc6CAgAEIAEELEDOggIABAeEAcQCkoECEEYAEoECEYYAFCxAli9J2DVOGgBcAF4AIABkgeIAYEvkgELMi02LjQuMi4xLjKYAQCgAQHIAQfAAQE&sclient=gws-wiz&tbs=lf:1,lf_ui:10&tbm=lcl&rflfq=1&num=10&rldimm=3416985104478402624&lqi=ChtyayB2YWxsZXkgIGdyb2Nlcnkgc2hvcHBpbmdIntbR6JWWgIAIWiwQAhADGAIYAyIacmsgdmFsbGV5IGdyb2Nlcnkgc2hvcHBpbmcqAggDKgIIApIBDWdyb2Nlcnlfc3RvcmWqARgQASoUIhBncm9jZXJ5IHNob3BwaW5nKAA&phdesc=fXQLto6BzJE&sa=X&rlst=f#rlfi=hd:;si:15128267738033756600,l,ChtyayB2YWxsZXkgIGdyb2Nlcnkgc2hvcHBpbmdI_NLAlaqvgIAIWiwQAhADGAIYAyIacmsgdmFsbGV5IGdyb2Nlcnkgc2hvcHBpbmcqAggCKgIIA5IBDWdyb2Nlcnlfc3RvcmWqARgQASoUIhBncm9jZXJ5IHNob3BwaW5nKAA,y,JPe9GDZjqZ4;mv:[[14.496063999999997,78.71765210000001],[14.1713534,78.2984221]]"><img src="del1.webp" class="card-img-top" width="350" height="350"></a>
                <div class="card-text"><center style="color:#ff7200;font-weight:bold;font-size:20px; padding-bottom: 10px;">Rk valley Store</center></div>
                <div class="card-text"><img src="pro1.png" style="border-radius:50%; padding-bottom: 10px;" width="40px" height="40px"> Narendrakumar</div>
                <div class="card-text" style="padding-left:30px;padding-bottom:20px">
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span></div>
                    <div class="card-text"><center><button type="button">View all</button></center></div>
                </div>
            </div>
       
        <div class="col-md-4">
            <div class="card">
            <a href="https://www.justdial.com/Kadapa/Grocery-Home-Delivery-Services/nct-10237940"><img src="del2.jpg" class="card-img-top"></a>
            <div class="card-text"><center style="color:#ff7200;font-weight:bold;font-size:20px;">Kadapa</center></div>
            <div class="card-text"><img src="pro3.png" style="border-radius:50%; padding-bottom: 10px;" width="40px" height="40px"> Sai krishna</div>
                <div class="card-text" style="padding-left:30px;padding-bottom:20px">
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star"></span></div>
                    <div class="card-text"><center><button type="button">View all</button></center></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
        <a href="https://www.justdial.com/Pulivendula/Grocery-Stores/nct-10237947"><img src="del3.webp" class="card-img-top"></a>
        <div class="card-text"><center style="color:#ff7200;font-weight:bold;font-size:20px;">Pulivendula</center></div>
        <div class="card-text"><img src="pro4.png" style="border-radius:50%; padding-bottom: 10px;" width="40px" height="40px"> Lokesh Naik</div>
                <div class="card-text" style="padding-left:30px;padding-bottom:20px">
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star"></span></div>
                    <div class="card-text"><center><button type="button">View all</button></center></div>
    </div>
</div>
<div class="col-md-4">
    <a href="https://www.justdial.com/Proddatur/Grocery-Stores/nct-10237947"><img src="del66.jpg" class="card-img-top"></a>
    <div class="card-text"><center style="color:#ff7200;font-weight:bold;font-size:20px;">Proddatur</center></div>
    <div class="card-text"><img src="pro2.png" style="border-radius:50%; padding-bottom: 10px;" width="40px" height="40px"> Harsha</div>
                <div class="card-text" style="padding-left:30px;padding-bottom:20px">
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span></div>
                    <div class="card-text"><center><button type="button">View all</button></center></div>
</div>
<div class="col-md-4">
    <div class="card">
    <a href="https://www.justdial.com/Kadapa/Grocery-Stores-in-Vaimpalle/nct-10237947"><img src="del44.jpg" class="card-img-top"></a>
    <div class="card-text"><center style="color:#ff7200;font-weight:bold;font-size:20px;">Vempalli</center></div>
    <div class="card-text"><img src="pro3.png" style="border-radius:50%; padding-bottom: 10px;" width="40px" height="40px"> Uma shankar</div>
                <div class="card-text" style="padding-left:30px;padding-bottom:20px">
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star"></span></div>
                    <div class="card-text"><center><button type="button">View all</button></center></div>
</div>
</div>
<div class="col-md-4">
    <div class="card">
       <a href="https://www.justdial.com/Kurnool/Grocery-Home-Delivery-Services/nct-10237940"><img src="del55.jpg" class="card-img-top" width="330" height="330"></a>
    <div class="card-text"><center style="color:#ff7200;font-weight:bold;font-size:20px;">Kurnool</center></div>
    <div class="card-text"><img src="pro1.png" style="border-radius:50%; padding-bottom: 10px;" width="40px" height="40px"> Bhaskar</div>
                <div class="card-text" style="padding-left:30px;padding-bottom:20px">
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star checked" style="color:#ff7200"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span></div>
                    <div class="card-text"><center><button type="button">View all</button></center></div>
</div>
</div>
</div>
    </div>
    <div class="ntg">
        <nav class="navbar navbar-expand-lg navbar-light fixed-bottom">
        <ul class="navbar-nav" style="background: radial-gradient(#fff,#ffd6d6);">
         <li class="nav-item">
         <a href="2.php" class="nav-link active"><i class="fa fa-home" style="font-size:28px; padding-left: 250px; padding-right: 350px"></i></a>
                                                                                                                            
         </li>
                                                                                                                                        
        <li class="nav-item">
        <a href="store.php" class="nav-link active"><i class='fa fa-shopping-bag' style='font-size:28px;padding-right: 350px;'></i></a>
        </li>  
        <li class="nav-item">
        <a href="mycart2.php" class="nav-link active"><i class="fa fa-shopping-cart" style="font-size:28px;padding-right: 350px;"></i></a>
                    </li>
                </nav>
        </div>
    <img src="Picsart_22-09-07_12-32-22-975.jpg" width="1400px" height="700px">
    </body>
</html>