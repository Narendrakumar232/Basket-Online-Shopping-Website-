<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Inpage</title>
        <link rel="stylesheet" href="2.css">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <?php
            $_SESSION['uname']=$_POST['uname'];
            $_SESSION['email']=$_POST['email'];
            
            ?>
        <div class="main" style=" width: 100%;
        background-color: green;
        background-position: center;
        background-size: cover;
        height: 30vh;">
         <div class="navbar" style="width:1200px; height:75px; margin:auto;">
            <div class="icon" style="width:200px; height:70px; float:left;">
                <h1 class="logo" style="color:#fff; font-size: 40px; font-family: Arial; padding-left: 3px; float:left; padding-top: 15px;">B a s k <i class="fa fa-shopping-cart" style="font-size:38px;color:#ff7200;"></i> t</h1> <a href="user.php"><i class="fa fa-user" style="font-size:38px; color:#fff; padding-left: 1200px; padding-top: 5px; margin-top: -55px;"></i></a>
                <p style="color:#fff; font-size: 13px; font-family: Arial; float: left;">Groceries delivered fresh and fast</p>
                <form style="margin-left: 400px;
                margin-top: 20px;
                font-size: 14px; padding: 12px; width: 340px;" >
                    <input type="search" placeholder="search..." class="st-default-search-input" style="width: 400px; height: 40px;">
                    <h1 style="margin-left:360px; margin-top:-48px"><i class="fa fa-search" style="font-size:26px"></i></h1>
                    <button class="btn btn-danger" style="margin-left:420px; margin-top:-78px">search</button>
                </form>
            </div>
        </div>
    </div>
    <div class="start">
        <h2>FREE delivery on your BASKET order</h2>
    </div><br><br><br><br>  
    <h2 style="margin-left: 50px;">Coupons For You</h2>

    <div class="container mt-2">
        <div class="carousel slide" id="slider" data-bs-ride="carousel">
            <ul class="carousel-indicators">
                <li data-bs-target="#slider" data-bs-slide-to="0" class="active"></li>
                <li data-bs-target="#slider" data-bs-slide-to="1"></li>
                <li data-bs-target="#slider" data-bs-slide-to="2"></li>
                <li data-bs-target="#slider" data-bs-slide-to="3"></li>
                <li data-bs-target="#slider" data-bs-slide-to="4"></li>
            </ul>
            <div class="carousel-inner" style="width: 1000px; height: 300px; align-items: left; background-size: cover; border-radius: 10px; left: 140px;">
                <div class="carousel-item active" data-bs-interval="2000"><img src="offer2.jpg" width="800" height="300"></div>
                <div class="carousel-item" data-bs-interval="2000"><img src="offer3.jpg" width="800" height="300"></div>
                <div class="carousel-item" data-bs-interval="2000"><img src="offer4.jpg" width="800" height="300"></div>
                <div class="carousel-item" data-bs-interval="2000"><img src="offer5.jpg" width="800" height="300"></div>
                <div class="carousel-item" data-bs-interval="2000"><img src="offer6.jpg" width="800" height="300"></div>
            </div>
        </div><br><br>
        <h2 style="margin-left: -60px;">Most Popular</h2>
                    <div class="row">
                        <div class="col-md-3">
                            <form action="managecart.php" method="POST">
                            <div class="card-header"><img src="brinjal.jpeg"></div>
                            <div class="card-body text-center">
                                <div class="card-title" style="font-weight:bold;">Lady's finger</div>
                                <div class="card-text">100 gms</div>
                            </div>
                            <div class="card-footer text-center" style="background-color:aqua;">
                                <nav class="navbar navbar-expand-lg">
                                    <ul class="navbar-nav">
                                        <li class="navbar-item" style="letter-spacing:1px;">
                                            <p style="font-size: 30px;"><i class="fa fa-rupee"></i>23  </p>
                                        </li>
                                        <li class="navbar-item">
                                            <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>25</s></p>
                                        </li>
                                        <li class="navbar-item">
                                            <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>2</p>
                                        </li>
                                    </ul>
                                </nav>
                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                <input type="hidden" name="item_name" value="Lady's finger">
                                <input type="hidden" name="price" value="23">
                            </div>
                            </form>
                        </div>
                        <div class="col-md-3">
                            <form action="managecart.php" method="POST">
                            <div class="card-header"><img src="carrot.jpeg"></div>
                            <div class="card-body text-center">
                                <div class="card-title" style="font-weight:bold;">Carrot</div>
                                <div class="card-text">500 gms</div>
                            </div>
                            <div class="card-footer text-center" style="background-color:aqua;">
                                <nav class="navbar navbar-expand-lg">
                                    <ul class="navbar-nav">
                                        <li class="navbar-item" style="letter-spacing:1px;">
                                            <p style="font-size: 30px;"><i class="fa fa-rupee"></i>40  </p>
                                        </li>
                                        <li class="navbar-item">
                                            <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>42 </s></p>
                                        </li>
                                        <li class="navbar-item">
                                            <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>2</p>
                                        </li>
                                    </ul>
                                </nav>
                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                <input type="hidden" name="item_name" value="Carrot">
                                <input type="hidden" name="price" value="40">
                            </div> 
                        </form>   
                    </div>
                    <div class="col-md-3">
                        <form action="managecart.php" method="POST">
                        <div class="card-header"><img src="apple.jpeg" height="190"></div>
                        <div class="card-body text-center">
                            <div class="card-title" style="font-weight:bold;">Apple-fuji</div>
                            <div class="card-text">4 pcs</div>
                        </div>
                        <div class="card-footer text-center" style="background-color:aqua;">
                            <nav class="navbar navbar-expand-lg">
                                <ul class="navbar-nav">
                                    <li class="navbar-item" style="letter-spacing:1px;">
                                        <p style="font-size: 30px;"><i class="fa fa-rupee"></i>136  </p>
                                    </li>
                                    <li class="navbar-item">
                                        <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>142 </s></p>
                                    </li>
                                    <li class="navbar-item">
                                        <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>6</p>
                                    </li>
                                </ul>
                            </nav>
                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                            <input type="hidden" name="item_name" value="Apple-fuji">
                            <input type="hidden" name="price" value="136">
                        </div>
                    </form>
                    </div>
                    <div class="col-md-3">
                        <form action="managecart.php" method="POST">
                        <div class="card-header"><img src="tamota.jpeg" height="190"></div>
                        <div class="card-body text-center">
                            <div class="card-title" style="font-weight:bold;">Tomato</div>
                            <div class="card-text">2 kgs</div>
                        </div>
                        <div class="card-footer text-center" style="background-color:aqua;">
                            <nav class="navbar navbar-expand-lg">
                                <ul class="navbar-nav">
                                    <li class="navbar-item" style="letter-spacing:1px;">
                                        <p style="font-size: 30px;"><i class="fa fa-rupee"></i>38  </p>
                                    </li>
                                    <li class="navbar-item">
                                        <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>40 </s></p>
                                    </li>
                                    <li class="navbar-item">
                                        <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>2</p>
                                    </li>
                                </ul>
                            </nav>
                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                        <input type="hidden" value="Tomato" name="item_name">
                        <input type="hidden" name="price" value="38">
                    </div>
                        </form>
                        </div>

                        <div class="col-md-3">
                            <form action="managecart.php" method="POST">
                            <div class="card-header"><img src="banana.jpeg" height="190"></div>
                            <div class="card-body text-center">
                                <div class="card-title" style="font-weight:bold;">Banana</div>
                                <div class="card-text">12 pcs</div>
                            </div>
                            <div class="card-footer text-center" style="background-color:aqua;">
                                <nav class="navbar navbar-expand-lg">
                                    <ul class="navbar-nav">
                                        <li class="navbar-item" style="letter-spacing:1px;">
                                            <p style="font-size: 30px;"><i class="fa fa-rupee"></i>59  </p>
                                        </li>
                                        <li class="navbar-item">
                                            <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>62 </s></p>
                                        </li>
                                        <li class="navbar-item">
                                            <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>3</p>
                                        </li>
                                    </ul>
                                </nav>
                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                <input type="hidden" value="Banana" name="item_name">
                                <input type="hidden" value="59" name="price">
                            </div>
                        </form>
                            </div>
                            <div class="col-md-3">
                                <form action="managecart.php" method="POST">
                                <div class="card-header"><img src="cucumber.jpeg" height="190"></div>
                                <div class="card-body text-center">
                                    <div class="card-title" style="font-weight:bold;">Cucumber</div>
                                    <div class="card-text">3 pcs</div>
                                </div>
                                <div class="card-footer text-center" style="background-color:aqua;">
                                    <nav class="navbar navbar-expand-lg">
                                        <ul class="navbar-nav">
                                            <li class="navbar-item" style="letter-spacing:1px;">
                                                <p style="font-size: 30px;"><i class="fa fa-rupee"></i>57  </p>
                                            </li>
                                            <li class="navbar-item">
                                                <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>60 </s></p>
                                            </li>
                                            <li class="navbar-item">
                                                <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>3</p>
                                            </li>
                                        </ul>
                                    </nav>
                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                    <input type="hidden" value="Cucumber" name="item_name">
                                    <input type="hidden" name="price" value="57">
                                </div>
                            </form>
                                </div>
                                <div class="col-md-3">
                                    <form action="managecart.php" method="POST">
                                    <div class="card-header"><img src="chips.jpeg" height="190"></div>
                                    <div class="card-body text-center">
                                        <div class="card-title" style="font-weight:bold;">Lays Classic Party Size</div>
                                        <div class="card-text">24 gms</div>
                                    </div>
                                    <div class="card-footer text-center" style="background-color:aqua;">
                                        <nav class="navbar navbar-expand-lg">
                                            <ul class="navbar-nav">
                                                <li class="navbar-item" style="letter-spacing:1px;">
                                                    <p style="font-size: 30px;"><i class="fa fa-rupee"></i>10  </p>
                                                </li>
                                                <li class="navbar-item">
                                                    <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>12 </s></p>
                                                </li>
                                                <li class="navbar-item">
                                                    <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>2</p>
                                                </li>
                                            </ul>
                                        </nav>
                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                        <input type="hidden" value="Lays Classic Party Size" name="item_name">
                                        <input type="hidden" name="price" value="10">
                                    </div>
                                </form>
                                    </div>
                                    <div class="col-md-3">
                                        <form action="managecart.php" method="POST">
                                        <div class="card-header"><img src="ashivadha.jpeg" height="190"></div>
                                        <div class="card-body text-center">
                                            <div class="card-title" style="font-weight:bold;">Aashirvaad Shudh ChakkiAtta</div>
                                            <div class="card-text">5 kgs</div>
                                        </div>
                                        <div class="card-footer text-center" style="background-color:aqua;">
                                            <nav class="navbar navbar-expand-lg">
                                                <ul class="navbar-nav">
                                                    <li class="navbar-item" style="letter-spacing:1px;">
                                                        <p style="font-size: 30px;"><i class="fa fa-rupee"></i>271  </p>
                                                    </li>
                                                    <li class="navbar-item">
                                                        <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>301 </s></p>
                                                    </li>
                                                    <li class="navbar-item">
                                                        <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>30</p>
                                                    </li>
                                                </ul>
                                            </nav>
                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                            <input type="hidden" value="Aashirvaad Shudh ChakkiAtta" name="item_name">
                                            <input type="hidden" name="price" value="271">
                                        </div>
                                    </form>
                                        </div>
                                        <div class="col-md-3">
                                            <form action="managecart.php" method="POST">
                                            <div class="card-header"><img src="dettol.jpeg" height="190"></div>
                                            <div class="card-body text-center">
                                                <div class="card-title" style="font-weight:bold;">Dettol Antiseptic</div>
                                                <div class="card-text">550 ml</div>
                                            </div>
                                            <div class="card-footer text-center" style="background-color:aqua;">
                                                <nav class="navbar navbar-expand-lg">
                                                    <ul class="navbar-nav">
                                                        <li class="navbar-item" style="letter-spacing:1px;">
                                                            <p style="font-size: 30px;"><i class="fa fa-rupee"></i>194  </p>
                                                        </li>
                                                        <li class="navbar-item">
                                                            <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>200 </s></p>
                                                        </li>
                                                        <li class="navbar-item">
                                                            <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>6</p>
                                                        </li>
                                                    </ul>
                                                </nav>
                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                <input type="hidden" name="price" value="194">
                                                <input type="hidden" value="Dettol Antiseptic" name="item_name">
                                            </div>
                                        </form>
                                            </div>
                                            <div class="col-md-3">
                                                <form action="managecart.php" method="POST">
                                                <div class="card-header"><img src="corn.jpeg" height="190" width="250"></div>
                                                <div class="card-body text-center">
                                                    <div class="card-title" style="font-weight:bold;">SweetCorn</div>
                                                    <div class="card-text">1 pcs</div>
                                                </div>
                                                <div class="card-footer text-center" style="background-color:aqua;">
                                                    <nav class="navbar navbar-expand-lg">
                                                        <ul class="navbar-nav">
                                                            <li class="navbar-item" style="letter-spacing:1px;">
                                                                <p style="font-size: 30px;"><i class="fa fa-rupee"></i>15  </p>
                                                            </li>
                                                            <li class="navbar-item">
                                                                <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>20 </s></p>
                                                            </li>
                                                            <li class="navbar-item">
                                                                <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>5</p>
                                                            </li>
                                                        </ul>
                                                    </nav>
                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                    <input type="hidden" value="SweetCorn" name="item_name">
                                                    <input type="hidden" name="price" value="15">
                                                </div>
                                            </form>
                                                </div>
                                                <div class="col-md-3">
                                                    <form action="managecart.php" method="POST">
                                                    <div class="card-header"><img src="tide.jpeg" height="190"></div>
                                                    <div class="card-body text-center">
                                                        <div class="card-title" style="font-weight:bold;">Tide liquid</div>
                                                        <div class="card-text">2 kgs</div>
                                                    </div>
                                                    <div class="card-footer text-center" style="background-color:aqua;">
                                                        <nav class="navbar navbar-expand-lg">
                                                            <ul class="navbar-nav">
                                                                <li class="navbar-item" style="letter-spacing:1px;">
                                                                    <p style="font-size: 30px;"><i class="fa fa-rupee"></i>250  </p>
                                                                </li>
                                                                <li class="navbar-item">
                                                                    <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>271 </s></p>
                                                                </li>
                                                                <li class="navbar-item">
                                                                    <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>21</p>
                                                                </li>
                                                            </ul>
                                                        </nav>
                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                        <input type="hidden" value="Tide liquid" name="item_name">
                                                        <input type="hidden" name="price" value="250">
                                                    </div>
                                                </form>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <form action="managecart.php" method="POST">
                                                        <div class="card-header"><img src="pineapple.jpeg" height="190"></div>
                                                        <div class="card-body text-center">
                                                            <div class="card-title" style="font-weight:bold;">pineapple</div>
                                                            <div class="card-text">1 pcs</div>
                                                        </div>
                                                        <div class="card-footer text-center" style="background-color:aqua;">
                                                            <nav class="navbar navbar-expand-lg">
                                                                <ul class="navbar-nav">
                                                                    <li class="navbar-item" style="letter-spacing:1px;">
                                                                        <p style="font-size: 30px;"><i class="fa fa-rupee"></i>30  </p>
                                                                    </li>
                                                                    <li class="navbar-item">
                                                                        <p style="padding-top: 12px; padding-left: 2px;"><s><i class="fa fa-rupee"></i>35 </s></p>
                                                                    </li>
                                                                    <li class="navbar-item">
                                                                        <p style="color:#ff7200; padding-top: 12px;">save <i class="fa fa-rupee"></i>5</p>
                                                                    </li>
                                                                </ul>
                                                            </nav>
                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                            <input type="hidden" value="Pineapple" name="item_name">
                                                            <input type="hidden" name="price" value="30">
                                                        </div>
                                                    </form>
                                                        </div>&nbsp;&nbsp;
                                                        <form action="managecart.php" method="POST">
                                                        <div class="combo">
                                                            <br>
                                                            <h2 style="color:white">Party Pack</h2>
                                                            <p style="padding-left: 80px; color:white;">One bag to bring it all</p>
                                                            <p style="padding-left: 80px; color:white;"><h3 style="padding-left: 80px; color:white"><i class="fa fa-rupee"></i><b>329</b></h3>&nbsp;&nbsp;&nbsp;<s style="padding-left: 80px; color:white"><i class="fa fa-rupee"></i> 417</s></p>
                                                            <h3 style="padding-left: 80px; color: #fff; color:white">+ Surprise Gift</h3>
                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px;margin-left: 80px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                            <input type="hidden" name="item_name" value="Party Pack">
                                                            <input type="hidden" name="price" value="329">
                                                            <img src="duss.gif" style="height: 250px;
                                                            position: absolute;
                                                            top: 2020px;
                                                            left: 500px;
                                                            border-radius: 10px;
                                                            padding: 25px;width: 250px;">
                                                            <img src="Picsart_22-08-20_16-33-53-113.png" style="width: 300px;
                                                            height: 300px;
                                                            position: absolute;
                                                            top: 2000px;
                                                            left: 870px;
                                                            border-radius: 10px;
                                                            padding: 25px;">
                                                        </div>&nbsp;&nbsp;
                                                        </form>
                                                        <h2 style="margin-left: -60px; padding-top:60px;">Fresh Vegetables<img src="fresh.jpeg" height="100"></h2>
                                                        <div class="row"  style="margin-left:-50px;">
                                                            <div class="col-md-2">
                                                            <form action="managecart.php" method="POST">
                                                                <div class="card-header"><img src="bitter.jpeg" height="200" width="150"></div>
                                                                <div class="card-body">
                                                                    <div class="card-title" style="font-weight:bold;">Bittergourd   1kg</div>
                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>20</h2></div>
                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                    <input type="hidden" name="item_name" value="Party Pack">
                                                                    <input type="hidden" name="price" value="329">
                                                                </div>
                                                                </form>
                                                                </div>
                                                                <div class="col-md-2">
                                                                <form action="managecart.php" method="POST">
                                                                    <div class="card-header"><img src="cauliflower.jpeg" height="200"></div>
                                                                    <div class="card-body">
                                                                        <div class="card-title" style="font-weight:bold;">Cabbage  1kg</div>
                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>15</h2></div>
                                                                        <button type="submit" name="add_to__cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                        <input type="hidden" name="item_name" value="Cabbage 1kg">
                                                                    <input type="hidden" name="price" value="15">
                                                                    </div> 
</form>
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                    <form action="managecart.php" method="POST">
                                                                        <div class="card-header"><img src="pinch2.jpeg" height="200" width="200"></div>
                                                                        <div class="card-body">
                                                                            <div class="card-title" style="font-weight:bold;">Pinch  1kg</div>
                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>50</h2></div>
                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                            <input type="hidden" name="item_name" value="Pinch 1kg">
                                                                    <input type="hidden" name="price" value="50">
                                                                </div></form>
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                        <form action="managecart.php" method="POST">
                                                                            <div class="card-header"><img src="drumstick.jpeg" height="200" width="200"></div>
                                                                            <div class="card-body">
                                                                                <div class="card-title" style="font-weight:bold;">Drumstick  2pcs</div>
                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>15</h2></div>
                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                <input type="hidden" name="item_name" value="Drumstick 2pc">
                                                                    <input type="hidden" name="price" value="15">
                                                                </div></form></div>
                                                                            <div class="col-md-2">
                                                                            <form action="managecart.php" method="POST">
                                                                                <div class="card-header"><img src="ridge.jpeg" height="200" width="200"></div>
                                                                                <div class="card-body">
                                                                                    <div class="card-title" style="font-weight:bold;">Ridge Gourd  500gms</div>
                                                                                    <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>37</h2></div>
                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                    <input type="hidden" name="item_name" value="Ridge Gourd 500gms">
                                                                    <input type="hidden" name="price" value="37">
                                                                </div></form></div>
                                                                                <div class="col-md-2">
                                                                                <form action="managecart.php" method="POST">
                                                                                    <div class="card-header"><img src="raddish.jpeg" height="200" width="200"></div>
                                                                                    <div class="card-body">
                                                                                        <div class="card-title" style="font-weight:bold;">Radish  250gms</div>
                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>7</h2></div>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                        <input type="hidden" name="item_name" value="Raddish 250gms">
                                                                    <input type="hidden" name="price" value="7"></div></form></div>
                                                            </div>
                                                            <div class="row"  style="margin-left:-50px;">
                                                                <div class="col-md-2">
                                                                <form action="managecart.php" method="POST">
                                                                    <div class="card-header"><img src="ginger.jpeg" height="200" width="150"></div>
                                                                    <div class="card-body">
                                                                        <div class="card-title" style="font-weight:bold;">Ginger  100gms</div>
                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>8</h2></div>
                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                        <input type="hidden" name="item_name" value="Ginder 100gms">
                                                                    <input type="hidden" name="price" value="8">
                                                                </div></form>
                                                                   
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                    <form action="managecart.php" method="POST">
                                                                        <div class="card-header"><img src="capsicum.jpeg" height="200" width="200"></div>
                                                                        <div class="card-body">
                                                                            <div class="card-title" style="font-weight:bold;">Capsicum  500gms</div>
                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>68</h2></div>
                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                            <input type="hidden" name="item_name" value="Capsicum 500gms">
                                                                    <input type="hidden" name="price" value="68"></div>
                                                                
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                        <form action="managecart.php" method="POST">
                                                                            <div class="card-header"><img src="cabage.jpeg" height="200" width="200"></div>
                                                                            <div class="card-body">
                                                                                <div class="card-title" style="font-weight:bold;">Cauliflower  1pc</div>
                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>58</h2></div>
                                                                                <button style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                <input type="hidden" name="item_name" value="Cauliflower 1pc">
                                                                    <input type="hidden" name="price" value="58"></div></form>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                            <form action="managecart.php" method="POST">
                                                                                <div class="card-header"><img src="potato.jpeg" height="200" width="180"></div>
                                                                                <div class="card-body">
                                                                                    <div class="card-title" style="font-weight:bold;">Potato 2kgs</div>
                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>76</h2></div>
                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                    <input type="hidden" name="item_name" value="Potato 2kg">
                                                                    <input type="hidden" name="price" value="76"></div></form></div>
                                                                                <div class="col-md-2">
                                                                                <form action="managecart.php" method="POST">
                                                                                    <div class="card-header"><img src="brinjal2.jpeg" height="200" width="200"></div>
                                                                                    <div class="card-body">
                                                                                        <div class="card-title" style="font-weight:bold;">Brinjal 500gms</div>
                                                                                        <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>20</h2></div>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                        <input type="hidden" name="item_name" value="Brinjal 500gms">
                                                                    <input type="hidden" name="price" value="20"></div></form></div>
                                                                                    <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                        <div class="card-header"><img src="chills.jpeg" height="200" width="200"></div>
                                                                                        <div class="card-body">
                                                                                            <div class="card-title" style="font-weight:bold;">Chilli GG  100gms</div>
                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>10</h2></div>
                                                                                            <button style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                            <input type="hidden" name="item_name" value="Chilli66 100gms 1kg">
                                                                    <input type="hidden" name="price" value="10"></div></form></div>
                                                                </div>

                                                                <div class="row"  style="margin-left:-50px;">
                                                                    <div class="col-md-2">
                                                                    <form action="managecart.php" method="POST">
                                                                        <div class="card-header"><img src="coriander.jpeg" height="200" width="150"></div>
                                                                        <div class="card-body">
                                                                            <div class="card-title" style="font-weight:bold;">Ginger  100gms</div>
                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>22</h2></div>
                                                                            <button  type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                            <input type="hidden" name="item_name" value="Ginger 100gms">
                                                                    <input type="hidden" name="price" value="22"></div></form>
                                                                       
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                        <form action="managecart.php" method="POST">
                                                                            <div class="card-header"><img src="onions.jpeg" height="200" width="200"></div>
                                                                            <div class="card-body">
                                                                                <div class="card-title" style="font-weight:bold;">Onion  1kg</div>
                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>27</h2></div>
                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                <input type="hidden" name="item_name" value="Onion 1kg">
                                                                    <input type="hidden" name="price" value="27"> </div>
                                                                    
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                            <form action="managecart.php" method="POST">
                                                                                <div class="card-header"><img src="garlic.jpeg" height="200" width="200"></div>
                                                                                <div class="card-body">
                                                                                    <div class="card-title" style="font-weight:bold;">Garlic  200gms</div>
                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>21</h2></div>
                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                    <input type="hidden" name="item_name" value="Garlic 200gms">
                                                                    <input type="hidden" name="price" value="21"></div></form>
                                                                                </div>
                                                                                <div class="col-md-2">
                                                                                <form action="managecart.php" method="POST">
                                                                                    <div class="card-header"><img src="ivy gourd.jpeg" height="200" width="180"></div>
                                                                                    <div class="card-body">
                                                                                        <div class="card-title" style="font-weight:bold;">Ivy Gourd 500gms</div>
                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>42</h2></div>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                        <input type="hidden" name="item_name" value="Ivy Gourd 500gms">
                                                                    <input type="hidden" name="price" value="42"></div></form></div>
                                                                                    <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                        <div class="card-header"><img src="beet.jpeg" height="200" width="200"></div>
                                                                                        <div class="card-body">
                                                                                            <div class="card-title" style="font-weight:bold;">Beetroot 500gms</div>
                                                                                            <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>42</h2></div>
                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                            <input type="hidden" name="item_name" value="Beetroot 500gms">
                                                                    <input type="hidden" name="price" value="42"></div></form></div>
                                                                                        <div class="col-md-2">
                                                                                        <form action="managecart.php" method="POST">
                                                                                            <div class="card-header"><img src="lemon.jpeg" height="200" width="200"></div>
                                                                                            <div class="card-body">
                                                                                                <div class="card-title" style="font-weight:bold;">Lemon 6pcs</div>
                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>29</h2></div>
                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                <input type="hidden" name="item_name" value="Lemon "6pcs>
                                                                    <input type="hidden" name="price" value="20"></div></form></div>

                                                                    </div>
                                                                    <img src="store-1.gif" width="350" height="350">
                                                                    <h2 style="margin-left: -60px; padding-top:60px;">Fresh Fruits<img src="fruits.jpeg" height="90" ></h2>

                                                                    <div class="row"  style="margin-left:-50px;">
                                                                        <div class="col-md-2">
                                                                        <form action="managecart.php" method="POST">
                                                                            <div class="card-header"><img src="watermelon.jpeg" height="200" width="150"></div>
                                                                            <div class="card-body">
                                                                                <div class="card-title" style="font-weight:bold;">Watermelon  1pc</div>
                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>38</h2></div>
                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                <input type="hidden" name="item_name" value="Watermelon 1pc">
                                <input type="hidden" name="price" value="38"></div></form>
                                                                           
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                            <form action="managecart.php" method="POST">
                                                                                <div class="card-header"><img src="papaya.jpeg" height="200" width="200"></div>
                                                                                <div class="card-body">
                                                                                    <div class="card-title" style="font-weight:bold;">Papaya  1pc</div>
                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>30</h2></div>
                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                    <input type="hidden" name="item_name" value="Papaya 1pc">
                                <input type="hidden" name="price" value="30"></div></form>
                                                                        
                                                                                </div>
                                                                                <div class="col-md-2">
                                                                                <form action="managecart.php" method="POST">
                                                                                    <div class="card-header"><img src="sapo2.jpeg" height="200" width="180"></div>
                                                                                    <div class="card-body">
                                                                                        <div class="card-title" style="font-weight:bold;">Sapota 5pcs</div>
                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>30</h2></div>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                        <input type="hidden" name="item_name" value="Sapota 5pcs">
                                <input type="hidden" name="price" value="30"> </div></form>
                                                                                    </div>
                                                                                    <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                        <div class="card-header"><img src="coco2.jpeg" height="200" width="200"></div>
                                                                                        <div class="card-body">
                                                                                            <div class="card-title" style="font-weight:bold;">Fresh Coconut 1pc</div>
                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>23</h2></div>
                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                            <input type="hidden" name="item_name" value="Fresh Coconut 1pc">
                                <input type="hidden" name="price" value="23"></div></form></div>
                                                                                        <div class="col-md-2">
                                                                                        <form action="managecart.php" method="POST">
                                                                                            <div class="card-header"><img src="musk.jpeg" height="200" width="200"></div>
                                                                                            <div class="card-body">
                                                                                                <div class="card-title" style="font-weight:bold;">Muskmelon 1pc</div>
                                                                                                <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>22</h2></div>
                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                <input type="hidden" name="item_name" value="Muskmelon 1pc">
                                <input type="hidden" name="price" value="22"></div></form></div>
                                                                                            <div class="col-md-2">
                                                                                            <form action="managecart.php" method="POST">
                                                                                                <div class="card-header"><img src="guvava.jpeg" height="200" width="200"></div>
                                                                                                <div class="card-body">
                                                                                                    <div class="card-title" style="font-weight:bold;">Guava 2pcs</div>
                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>15</h2></div>
                                                                                                    <button type="submit" value="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                    <input type="hidden" name="item_name" value="Guava 2pcs">
                                <input type="hidden" name="price" value="15"></div></form></div>
                                                                        </div>
                                                                        <div class="row"  style="margin-left:-50px;">
                                                                            <div class="col-md-2">
                                                                            <form action="managecart.php" method="POST">
                                                                                <div class="card-header"><img src="mango.jpg" height="200" width="150"></div>
                                                                                <div class="card-body">
                                                                                    <div class="card-title" style="font-weight:bold;">Mangoes RC 6pc</div>
                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>138</h2></div>
                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                    <input type="hidden" name="item_name" value="Mangoes Rc 6pc">
                                <input type="hidden" name="price" value="138"></div></form>
                                                                               
                                                                                </div>
                                                                                <div class="col-md-2">
                                                                                <form action="managecart.php" method="POST">
                                                                                    <div class="card-header"><img src="staw.jpeg" height="200" width="200"></div>
                                                                                    <div class="card-body">
                                                                                        <div class="card-title" style="font-weight:bold;">Stawberry  6pc</div>
                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>130</h2></div>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                        <input type="hidden" name="item_name" value="Stawberry 6pcs">
                                <input type="hidden" name="price" value="130"></div></form>
                                                                            
                                                                                    </div>
                                                                                    <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                        <div class="card-header"><img src="promogrante.jpeg" height="200" width="180"></div>
                                                                                        <div class="card-body">
                                                                                            <div class="card-title" style="font-weight:bold;">Pomegranate 2pcs</div>
                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>75</h2></div>
                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                            <input type="hidden" name="item_name" value="Pomegranate 2pcs">
                                <input type="hidden" name="price" value="75"></div></form>
                                                                                        </div>
                                                                                        <div class="col-md-2">
                                                                                        <form action="managecart.php" method="POST">
                                                                                            <div class="card-header"><img src="lychees.jpeg" height="200" width="180"></div>
                                                                                            <div class="card-body">
                                                                                                <div class="card-title" style="font-weight:bold;">Lychees 6pcs</div>
                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>180</h2></div>
                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                <input type="hidden" name="item_name" value="Lychees 6pcs">
                                <input type="hidden" name="price" value="180"></div></form></div>
                                                                                            <div class="col-md-2">
                                                                                            <form action="managecart.php" method="POST">
                                                                                                <div class="card-header"><img src="grapes.jpeg" height="200" width="200"></div>
                                                                                                <div class="card-body">
                                                                                                    <div class="card-title" style="font-weight:bold;">Grapes  500gms</div>
                                                                                                    <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>45</h2></div>
                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                    <input type="hidden" name="item_name" value="Grapes 500gms">
                                <input type="hidden" name="price" value="45"></div></form></div>
                                                                                                <div class="col-md-2">
                                                                                                <form action="managecart.php" method="POST">
                                                                                                    <div class="card-header"><img src="orange.jpeg" height="200" width="200"></div>
                                                                                                    <div class="card-body">
                                                                                                        <div class="card-title" style="font-weight:bold;">Orange 2pcs</div>
                                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>83</h2></div>
                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                        <input type="hidden" name="item_name" value="Orange 2pcs">
                                <input type="hidden" name="price" value="83"> </div></form></div>
                                                                            </div>

                                                                            <div class="combo2">
                                                                            <form action="managecart.php" method="POST">
                                                                                <br>
                                                                                <h2>Health & Hygiene</h2>
                                                                                <p style="padding-left: 80px;">Cleaning Essentials</p>
                                                                        
                                                                                <h3 style="padding-left: 80px; color: #fff;">Up to 20% OFF</h3>
                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; margin-left:80px;border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                <input type="hidden" name="item_name" value="Cleaning Essentials"><input type="hidden" name="price" value="300"><img src="Picsart_22-08-20_21-39-15-662.png" style="width: 300px;
                                                                                height: 260px;
                                                                                position: absolute;
                                                                                top: 4880px;
                                                                                left: 870px;
                                                                                border-radius: 10px;
                                                                                padding: 25px;">
                                                                            </div></form>
                                                                            <h2 style="margin-left: -60px; padding-top:60px;">Breakfast and Dairy<img src="break.jpg" height="120" ></h2>
                                                                            <div class="row"  style="margin-left:-50px;">
                                                                                <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                    <div class="card-header"><img src="milk.jpeg" height="200" width="150"></div>
                                                                                    <div class="card-body">
                                                                                        <div class="card-title" style="font-weight:bold;">Milk 1 ltr</div>
                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>43</h2></div>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button></div>
                                                                                        <input type="hidden" name="item_name" value="Milk 1ltr">
                                                                                         <input type="hidden" name="price" value="43">
                                                                                    </div></form>
                                                                                    <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                        <div class="card-header"><img src="cornsp.jpeg" height="200" width="200"></div>
                                                                                        <div class="card-body">
                                                                                            <div class="card-title" style="font-weight:bold;">Corn Flakes 250grms</div>
                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>91</h2></div>
                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button> </div>
                                                                                            <input type="hidden" name="item_name" value="Corn Flakes 250gms">
                                                                                         <input type="hidden" name="price" value="91">
                                                                                        </div></form>
                                                                                        <div class="col-md-2">
                                                                                        <form action="managecart.php" method="POST">
                                                                                            <div class="card-header"><img src="egg2.jpeg" height="200" width="180"></div>
                                                                                            <div class="card-body">
                                                                                                <div class="card-title" style="font-weight:bold;">Eggs 6pcs</div>
                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>57</h2></div>
                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button></div>
                                                                                                <input type="hidden" name="item_name" value="Eggs 6pcs">
                                                                                         <input type="hidden" name="price" value="57"></div></form>
                                                                                            <div class="col-md-2">
                                                                                            <form action="managecart.php" method="POST">
                                                                                                <div class="card-header"><img src="choco.jpeg" height="200" width="180"></div>
                                                                                                <div class="card-body text-center">
                                                                                                    <div class="card-title" style="font-weight:bold;">Chocos 50grms</div>
                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>20</h2></div>
                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                    <input type="hidden" name="item_name" value="Chocos 50gms">
                                                                                         <input type="hidden" name="price" value="20"></div></form></div>
                                                                                                <div class="col-md-2">
                                                                                                <form action="managecart.php" method="POST">
                                                                                                    <div class="card-header"><img src="cheese.jpg" height="200" width="200"></div>
                                                                                                    <div class="card-body text-center text-center">
                                                                                                        <div class="card-title" style="font-weight:bold;">Cheese 250grms</div>
                                                                                                        <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>119</h2></div>
                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                        <input type="hidden" name="item_name" value="Cheese 250gms">
                                                                                         <input type="hidden" name="price" value="119"></div></div>
                                                                                                    <div class="col-md-2">
                                                                                                    <form action="managecart.php" method="POST">
                                                                                                        <div class="card-header"><img src="pop.jpeg" height="200" width="200"></div>
                                                                                                        <div class="card-body text-center text-center">
                                                                                                            <div class="card-title" style="font-weight:bold;">Popcorn 1pcs</div>
                                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>15</h2></div>
                                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                            <input type="hidden" name="item_name" value="Popcorn 1pcs">
                                                                                         <input type="hidden" name="price" value="15"></div></div>
                                                                                </div>
                                                                                <h2 style="margin-left: -60px; padding-top:60px;">Snacks & Beverages <img src="snack.jpeg" height="120" ></h2>
                                                                                         
                                                                
                                                                                <div class="row"  style="margin-left:-50px;">
                                                                                    <div class="col-md-2">
                                                                                    <form action="managecart.php" method="POST">
                                                                                        <div class="card-header"><img src="bis.png" height="200" width="150"></div>
                                                                                        <div class="card-body text-center text-center">
                                                                                            <div class="card-title" style="font-weight:bold;">Goodday Butter 68gms</div>
                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>10</h2></div>
                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                            <input type="hidden" name="item_name" value="Goodday Butter 68gms">
                                                                                         <input type="hidden" name="price" value="10"></div></form>
                                                                                        </div>
                                                                                        <div class="col-md-2">
                                                                                        <form action="managecart.php" method="POST">
                                                                                            <div class="card-header"><img src="chips.jpeg" height="200" width="200"></div>
                                                                                            <div class="card-body text-center text-center">
                                                                                                <div class="card-title" style="font-weight:bold;">Lays Classic 90gms</div>
                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>45</h2></div>
                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button></div>
                                                                                                <input type="hidden" name="item_name" value="Lays Classic 90gms">
                                                                                         <input type="hidden" name="price" value="45"></form>
                                                                                            </div>
                                                                                            <div class="col-md-2">
                                                                                            <form action="managecart.php" method="POST">
                                                                                                <div class="card-header"><img src="thumb.jpg" height="200" width="180"></div>
                                                                                                <div class="card-body text-center text-center">
                                                                                                    <div class="card-title" style="font-weight:bold;">Thumbsup 500ml</div>
                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>38</h2></div>
                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                    <input type="hidden" name="item_name" value="Thumbsup 500ml">
                                                                                         <input type="hidden" name="price" value="38"></div></form>
                                                                                                </div>
                                                                                                <div class="col-md-2">
                                                                                                <form action="managecart.php" method="POST">
                                                                                                    <div class="card-header"><img src="lays.jpeg" height="200" width="180"></div>
                                                                                                    <div class="card-body text-center text-center">
                                                                                                        <div class="card-title" style="font-weight:bold;">Lays 55gms</div>
                                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>20</h2></div>
                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                        <input type="hidden" name="item_name" value="Lays 55gms">
                                                                                         <input type="hidden" name="price" value="20"></div></form></div>
                                                                                                    <div class="col-md-2">
                                                                                                    <form action="managecart.php" method="POST">
                                                                                                        <div class="card-header"><img src="sprite.jpg" height="200" width="200"></div>
                                                                                                        <div class="card-body text-centertext-center">
                                                                                                            <div class="card-title" style="font-weight:bold;">Sprite 2.25ml</div>
                                                                                                            <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>95</h2></div>
                                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                            <input type="hidden" name="item_name" value="Sprite 2.25ml">
                                                                                         <input type="hidden" name="price" value="95"></div></form></div>
                                                                                                        <div class="col-md-2">
                                                                                                        <form action="managecart.php" method="POST">
                                                                                                            <div class="card-header"><img src="bis2.jpeg" height="200" width="200"></div>
                                                                                                            <div class="card-body text-center text-center">
                                                                                                                <div class="card-title" style="font-weight:bold;">Bourbon 100gms</div>
                                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>20</h2></div>
                                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                <input type="hidden" name="item_name" value="Bourbon 100gms">
                                                                                         <input type="hidden" name="price" value="20"></div></form></div>
                                                                                    </div>
                                                                                    <div class="combo3 mt-5">
                                                                                        <br>
                                                                                        <form action="managecart.php" method="POST">
                                                                                        <h2>Rosy & Sweet Shimla Apples</h2>
                                                                                        <p style="padding-left: 80px; color:#fff">Now  available on</p>
                                                                                        <h3 style="padding-left: 80px; color:#fff">BASKET Daily</h3>
                                                                                        <button type="submit" name="add_to_cart" style="background-color:white; color: black; padding: 5px; margin-left:80px;border: none; outline: none; font-weight: bold; color:black;cursor: pointer;border-radius: 10px;">Add cart</button>&nbsp;<span></span>
                                                                                        <input type="hidden" name="item_name" value="Rosy & Sweet Shimla Apples 10pcs">
                                                                                         <input type="hidden" name="price" value="400">
                                                                                        <img src="Picsart_22-08-20_22-47-02-044.png" style="width: 300px;
                                                                                        height: 300px;
                                                                                        position: absolute;
                                                                                        top: 6220px;
                                                                                        left: 870px;
                                                                                        border-radius: 10px;
                                                                                        padding: 25px;">
                                                                                    </div>
                                                                                    <h2 style="margin-left: -60px; padding-top:60px;">Home Essentials <img src="home.jpg" height="150" ></h2>
                                                                                    <div class="row"  style="margin-left:-50px;">
                                                                                        <div class="col-md-2">
                                                                                        <form action="managecart.php" method="POST">
                                                                                            <div class="card-header"><img src="oil.jpg" height="200" width="150"></div>
                                                                                            <div class="card-body text-center text-center">
                                                                                                <div class="card-title" style="font-weight:bold;">Freedom Sunflower   1ltr</div>
                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>183</h2></div>
                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                <input type="hidden" name="item_name" value="Freedom Sunflower 1ltr">
                                                                                         <input type="hidden" name="price" value="183"></div></form>
                                                                                           
                                                                                            </div>
                                                                                            <div class="col-md-2">
                                                                                            <form action="managecart.php" method="POST">
                                                                                                <div class="card-header"><img src="salt.jpeg" height="200"></div>
                                                                                                <div class="card-body text-center text-center">
                                                                                                    <div class="card-title" style="font-weight:bold;">Aashirvaad Salt  1kg</div>
                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>20</h2></div>
                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                    <input type="hidden" name="item_name" value="Aashirvaad Salt 1kg">
                                                                                         <input type="hidden" name="price" value="20"></div></form>
                                                                                        
                                                                                                </div>
                                                                                                <div class="col-md-2">
                                                                                                <form action="managecart.php" method="POST">
                                                                                                    <div class="card-header"><img src="masala.jpeg" height="200" width="200"></div>
                                                                                                    <div class="card-body text-center text-center">
                                                                                                        <div class="card-title" style="font-weight:bold;">Aachi Chicken Masala  100gms</div>
                                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>80</h2></div>
                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                        <input type="hidden" name="item_name" value="Aachi Chicken Masala 100gms">
                                                                                         <input type="hidden" name="price" value="80"></div></form>
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                    <form action="managecart.php" method="POST">
                                                                                                        <div class="card-header"><img src="teramric.jpg" height="200" width="200"></div>
                                                                                                        <div class="card-body text-center text-center">
                                                                                                            <div class="card-title" style="font-weight:bold;">Turmeric Powder 100gms</div>
                                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>28</h2></div>
                                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                            <input type="hidden" name="item_name" value="Turmeric Powder 100gms">
                                                                                         <input type="hidden" name="price" value="28"></div></form></div>
                                                                                                        <div class="col-md-2">
                                                                                                        <form action="managecart.php" method="POST">
                                                                                                            <div class="card-header"><img src="tea.jpg" height="200" width="200"></div>
                                                                                                            <div class="card-body text-center text-center">
                                                                                                                <div class="card-title" style="font-weight:bold;">3 Roses TeaPowder  250gms</div>
                                                                                                                <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>200</h2></div>
                                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                <input type="hidden" name="item_name" value="#Roses TeaPowder 250gms">
                                                                                         <input type="hidden" name="price" value="200"></div></form></div>
                                                                                                            <div class="col-md-2">
                                                                                                            <form action="managecart.php" method="POST">
                                                                                                                <div class="card-header"><img src="chillipowder.jpg" height="200" width="200"></div>
                                                                                                                <div class="card-body text-center text-center">
                                                                                                                    <div class="card-title" style="font-weight:bold;">Red Chillipowder  200gms</div>
                                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>75</h2></div>
                                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                    <input type="hidden" name="item_name" value="Red chillipowder 200gms">
                                                                                         <input type="hidden" name="price" value="75"></div></form></div>
                                                                                        </div>
                                                                                        <div class="row"  style="margin-left:-50px; justify-content: space-around;">
                                                                                            <div class="col-md-2">
                                                                                            <form action="managecart.php" method="POST">
                                                                                                <div class="card-header"><img src="santoor.jpeg" height="200" width="150"></div>
                                                                                                <div class="card-body text-center">
                                                                                                    <div class="card-title" style="font-weight:bold;">Santoor pack of 4*100gms</div>
                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>146</h2></div>
                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                    <input type="hidden" name="item_name" value="Santoor pack 4*100gms">
                                                                                         <input type="hidden" name="price" value="146"></div></form>
                                                                                               
                                                                                                </div>
                                                                                                <div class="col-md-2">
                                                                                                <form action="managecart.php" method="POST">
                                                                                                    <div class="card-header"><img src="med.jpg" height="200" width="200"></div>
                                                                                                    <div class="card-body text-center">
                                                                                                        <div class="card-title" style="font-weight:bold;">Medimix 100gms</div>
                                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>30</h2></div>
                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                        <input type="hidden" name="item_name" value="Medimix 100gms">
                                                                                         <input type="hidden" name="price" value="30"></div></form>
                                                                                            
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                    <form action="managecart.php" method="POST">
                                                                                                        <div class="card-header"><img src="meera.jpg" height="200" width="200"></div>
                                                                                                        <div class="card-body text-center">
                                                                                                            <div class="card-title" style="font-weight:bold;">Meera Shampoo  185ml</div>
                                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>68</h2></div>
                                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                            <input type="hidden" name="item_name" value="Meera Shampoo 185ml">
                                                                                         <input type="hidden" name="price" value="68"></div></form>
                                                                                                        </div>
                                                                                                        <div class="col-md-2">
                                                                                                        <form action="managecart.php" method="POST">
                                                                                                            <div class="card-header"><img src="clinic.jpg" height="200" width="180"></div>
                                                                                                            <div class="card-body text-center">
                                                                                                                <div class="card-title" style="font-weight:bold;">Clinic Plus 355ml</div>
                                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>214</h2></div>
                                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                <input type="hidden" name="item_name" value="Clinic Plus 355ml">
                                                                                         <input type="hidden" name="price" value="214"></div></form></div>
                                                                                                            <div class="col-md-2">
                                                                                                            <form action="managecart.php" method="POST">
                                                                                                                <div class="card-header"><img src="para.jpg" height="200" width="200"></div>
                                                                                                                <div class="card-body text-center">
                                                                                                                    <div class="card-title" style="font-weight:bold;">Parachute 200ml</div>
                                                                                                                    <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>83</h2></div>
                                                                                                                    <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button> 
                                                                                                                    <input type="hidden" name="item_name" value="Parachute 200ml">
                                                                                         <input type="hidden" name="price" value="83"></div></form></div>
                                                                                                                <div class="col-md-2">
                                                                                                                <form action="managecart.php" method="POST">
                                                                                                                    <div class="card-header"><img src="almond.jpg" height="200" width="200"></div>
                                                                                                                    <div class="card-body">
                                                                                                                        <div class="card-title" style="font-weight:bold;">Almond  190ml</div>
                                                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>75</h2></div>
                                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                        <input type="hidden" name="item_name" value="Almond 190ml">
                                                                                         <input type="hidden" name="price" value="75"></div></form></div>
                                                                                            </div>
                            
                                                                                            <div class="row"  style="margin-left:-50px;">
                                                                                                <div class="col-md-2">
                                                                                                <form action="managecart.php" method="POST">
                                                                                                    <div class="card-header"><img src="vim.jpg" height="200" width="150"></div>
                                                                                                    <div class="card-body text-center">
                                                                                                        <div class="card-title" style="font-weight:bold;">Vim  125gms</div>
                                                                                                        <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>10</h2></div>
                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                        <input type="hidden" name="item_name" value="Vim 125gms">
                                                                                         <input type="hidden" name="price" value="10"></div></form>
                                                                                                   
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                    <form action="managecart.php" method="POST">
                                                                                                        <div class="card-header"><img src="surf.jpg" height="200" width="200"></div>
                                                                                                        <div class="card-body text-center">
                                                                                                            <div class="card-title" style="font-weight:bold;">Surf Excel 1kg</div>
                                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>144</h2></div>
                                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                            <input type="hidden" name="item_name" value="Surf Excel 1kg">
                                                                                         <input type="hidden" name="price" value="144"></div></form>
                                                                                                
                                                                                                        </div>
                                                                                                        <div class="col-md-2">
                                                                                                        <form action="managecart.php" method="POST">
                                                                                                            <div class="card-header"><img src="paste.jpg" height="200" width="200"></div>
                                                                                                            <div class="card-body text-center">
                                                                                                                <div class="card-title" style="font-weight:bold;">DabarRed paste  175gms</div>
                                                                                                                <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>59</h2></div>
                                                                                                                <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                <input type="hidden" name="item_name" value="DabarRed paste 175gms">
                                                                                         <input type="hidden" name="price" value="59"></div></form>
                                                                                                            </div>
                                                                                                            <div class="col-md-2">
                                                                                                            <form action="managecart.php" method="POST">
                                                                                                                <div class="card-header"><img src="hit.jpg" height="200" width="180"></div>
                                                                                                                <div class="card-body text-center">
                                                                                                                    <div class="card-title" style="font-weight:bold;">Godrej Hit 200ml</div>
                                                                                                                    <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>101</h2></div>
                                                                                                                    <button type="submit" name="ad_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                    <input type="hidden" name="item_name" value="Godrej Hit 200ml">
                                                                                         <input type="hidden" name="price" value="101"></div></div>
                                                                                                                <div class="col-md-2">
                                                                                                                <form action="managecart.php" method="POST">
                                                                                                                    <div class="card-header"><img src="comfort.jpg" height="200" width="200"></div>
                                                                                                                    <div class="card-body text-center">
                                                                                                                        <div class="card-title" style="font-weight:bold;">Comfort 430ml</div>
                                                                                                                        <div class="card-text"><h2 style="color:rgb(8, 8, 8);"><i class="fa fa-rupee"></i>120</h2></div>
                                                                                                                        <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button>
                                                                                                                        <input type="hidden" name="item_name" value="comfort 430ml">
                                                                                         <input type="hidden" name="price" value="120"> </div></div>
                                                                                                                    <div class="col-md-2">
                                                                                                                    <form action="managecart.php" method="POST">
                                                                                                                        <div class="card-header"><img src="rin.jpg" height="200" width="200"></div>
                                                                                                                        <div class="card-body text-center">
                                                                                                                            <div class="card-title" style="font-weight:bold;">Rin Bar 130gms</div>
                                                                                                                            <div class="card-text"><h2 style="color:rgb(8,8,8);"><i class="fa fa-rupee"></i>10</h2></div>
                                                                                                                            <button type="submit" name="add_to_cart" style="background-color:red;color: white; padding: 5px; border: none; outline: none; font-weight: bold; color:#fafafa;cursor: pointer;border-radius: 10px;">Add cart</button> 
                                                                                                                            <input type="hidden" name="item_name" value="Rin Bar 130gms">
                                                                                         <input type="hidden" name="price" value="10"></div></div>
                                                                                                                        </div>
                                                                                                                       
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-1">.</div>
                                                                                                                        </div>
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-1"></div>
                                                                                                                        </div>
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-md-1">.</div>
                                                                                                                        </div>
                                                                                                                        

                                                                                                                        <div class="ntg">
                                                                                                                            <nav class="navbar navbar-expand-lg navbar-light fixed-bottom">
                                                                                                                                <ul class="navbar-nav" style="background: radial-gradient(#fff,#ffd6d6);">
                                                                                                                                    <li class="nav-item">
                                                                                                                                        <a href="#" class="nav-link active"><i class="fa fa-home" style="font-size:28px; padding-left: 250px; padding-right: 350px"></i></a>
                                                                                                                        
                                                                                                                                    </li>
                                                                                                                                    
                                                                                                                                    <li class="nav-item">
                                                                                                                                        <a href="store.php" class="nav-link active"><i class='fa fa-shopping-bag' style='font-size:28px;padding-right: 350px;'></i></a>
                                                                                                                                    </li>
                                                                                                                                    <li class="nav-item">
                                                                                                                                        <?php
                                                                                                                                            $count=0;
                                                                                                                                            if(isset($_SESSION['cart']))
                                                                                                                                            {
                                                                                                                                                $count=count($_SESSION['cart']);
                                                                                                                                            }
                                                                                                                                            ?>
                                                                                                                                        <a href="mycart2.php" class="nav-link active"><i class="fa fa-shopping-cart" style="font-size:28px;padding-right: 350px;"><span style="color:red; margin-left:10px;">(<?php echo $count; ?>)</span></i></a>
                                                                                                                                    </li>
                                                                                                                                    </ul>
                                                                                                                                    
                                                                                                                                </nav>
                                                                                                                                </div>


























                    </div>
    </div></div>
<img src="Picsart_22-09-07_12-32-22-975.jpg" width="1400px" height="800px">
    </body>
 </html>