<!DOCTYPE html>
<html><head>
    <title>ABOUT</title>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="main" style=" width: 100%;
        background-color:rgb(65, 71, 69);
        background-position: center;
        background-size: cover;
        height: 45vh;">
        <h1 class="logo" style="color:rgb(19, 241, 19); font-size: 60px; font-family:Arial Narrow Bold; font-weight: bold; padding-left: 36%; float:left; padding-top: 60px;">B a s k <i class="fa fa-shopping-cart" style="font-size:60px;color:#ff7200;"></i> t</h1>
        <p style="padding-left: 38%; float:left; padding-top: 30px; color:white;  font-size: 30px;">Terms and Conditions</p>
        </div>
        <h1 align="center" style="padding-top:40px">User Terms</h1>
        <h5 style="padding-left:20%; padding-right:20%">While it’s not legally required for ecommerce websites to have a terms and conditions agreement, adding one will help protect your online business.

            As terms and conditions are legally enforceable rules, they allow you to set standards for how users interact with your <b style="color:green";>BASKET</b> site. Here are some of the major benefits of including terms and conditions on your ecommerce site</h5>
    
            <h5 style="padding-left:20%; padding-right:20%">By setting guidelines on proper site usage, terms inform users what constitutes acceptable actions when using your site, and the consequences of breaking those rules.

                Examples of unacceptable behaviors include spamming, using bots, or posting defamatory content. Having terms and conditions allows you to take action against site abusers by banning them or terminating their accounts</h5>
                <h1 align="center" style="padding-top:40px">Business to business (B2B)</h1>
                <h5 style="padding-left:20%; padding-right:20%">A situation where one business conducts a <span style="color:green;">commercial transaction</span> with another is known as a Business-to-business (B2B) service. It generally emerges when a business is sourcing material for the production process to get output, i.e., offering raw materials to the other brand that will produce output.</h5>

                </body>
</html>