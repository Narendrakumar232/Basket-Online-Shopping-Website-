<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewpoint" content="width=device-width, initial-scale=1.0">
        <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>cart</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center border rounded bg-success my-5">
                <h1>MY CART</h1>
            </div>

            <div class="col-lg-9">
                <table class="table">
                <thead class="text-center">
                   
                    <tr>
                    <th scope="col">Serial No.</th>
                    <th scope="col">Item Name</th>
                    <th scope="col">Item Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody class="text-center">
                <?php
                    $total=0;
                        if(isset($_SESSION['cart']))
                        {
                        foreach($_SESSION['cart']as $key => $value)
                        {
                            $total=$total+$value['price'];
                            echo "
                            <tr>
                                <td>1</td>
                                <td>$value[item_name]</td>
                                <td>$value[price]</td>
                                <td><input class='text-center' type='number' size='2' min='1' max='10' value='$value[Quantity]'></td>
                                <td>
                                <form action='managecart.php' method='POST'>
                                <button name='remove_item' class='btn btn-outline-danger btn-sm'>Remove</button>
                                <input type='hidden' name='item_name' value='$value[item_name]'>
                                </form>
                                </td>
                            </tr>
                            ";
                        }
                    }
                        ?>
                    
                </tbody>
                </table>
            </div>

            <div class="col-lg-3">
                <div class="border bg-light rounded p-4">
                <h4>Total:</h4><br>
                <h5 class="text-center"><i class="fa fa-rupee"></i><?php  echo $total; ?></h5><br>
                 <?php
               if($total>0){
		       echo "<form action='address.php' method='POST'>
		            <center><button class='btn btn-primary btn-block'>Make Payments</button></center>
		        </form>";
		        }
		else{
			echo "<script>
				alert('NO items added');
				</script>";}
				?>
                </div>
            </div>

        </div>
    </div>

    <div class="ntg">
    <nav class="navbar navbar-expand-lg navbar-light fixed-bottom">
    <ul class="navbar-nav" style="background: radial-gradient(#fff,#ffd6d6);">
     <li class="nav-item">
     <a href="2.php" class="nav-link active"><i class="fa fa-home" style="font-size:28px; padding-left: 250px; padding-right: 350px"></i></a>
                                                                                                                        
     </li>
                                                                                                                                    
    <li class="nav-item">
    <a href="store.php" class="nav-link active"><i class='fa fa-shopping-bag' style='font-size:28px;padding-right: 350px;'></i></a>
    </li>  
    <li class="nav-item">
    <a href="mycart2.php" class="nav-link active"><i class="fa fa-shopping-cart" style="font-size:28px;padding-right: 350px;"></i></a>
                </li>
            </nav>
    </div>                                                                                                                
</body>
    </html>

